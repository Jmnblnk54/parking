export const COMETCHAT_CONSTANTS = {
    APP_ID: '212901b2eeacd7c6',
    REGION: 'us',
    AUTH_KEY: '8e3fded52de08d4314b444c6c94b416a0587146f',
    UID: 'SUPERHERO1'
}